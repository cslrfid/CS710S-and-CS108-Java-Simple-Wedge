package org.epctagcoder.exception;

public class EPCParseException extends Exception {

    public EPCParseException(String message) {
        super(message);
    }	
    
	 
}
